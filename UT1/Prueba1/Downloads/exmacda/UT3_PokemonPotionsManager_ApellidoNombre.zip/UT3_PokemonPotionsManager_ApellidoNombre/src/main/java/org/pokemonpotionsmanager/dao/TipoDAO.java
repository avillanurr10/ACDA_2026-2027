package org.pokemonpotionsmanager.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.pokemonpotionsmanager.connection.HibernateUtil;
import org.pokemonpotionsmanager.model.Tipo;
import org.hibernate.query.Query;

import java.util.List;

/**
 * DAO encargado de gestionar las operaciones CRUD
 * y consultas HQL para la entidad {@link Tipo}.
 * <p>
 * Implementa la interfaz genérica {@link IGenericDAO}.
 * </p>
 *
 * @see Tipo
 * @see IGenericDAO
 * @see org.pokemonpotionsmanager.connection.HibernateUtil
 *
 * @author Dani Durán
 * @version 1.1
 */
public class TipoDAO implements IGenericDAO<Tipo, Integer> {

    /** Inserta un nuevo tipo en la base de datos. */
    @Override
    public void insertar(Tipo tipo) {
        // TODO
    }

    /** Actualiza un tipo existente. */
    @Override
    public void actualizar(Tipo tipo) {
        // TODO
    }

    /** Elimina un tipo por su identificador. */
    @Override
    public void eliminar(Integer id) {
        // TODO
    }

    /** Busca un tipo por su ID. */
    @Override
    public Tipo buscarPorId(Integer id) {
        // TODO
    }

    /** Lista todos los tipos registrados. */
    @Override
    public List<Tipo> listarTodos() {
        // TODO
    }

    /**
     * Consulta HQL de agregación que cuenta cuántas pociones hay asociadas a cada tipo.
     * <p>
     * Utiliza un {@code LEFT JOIN} con la colección de pociones.
     * </p>
     *
     * @return Lista de pares [nombre del tipo, número de pociones].
     */
    public List<Object[]> contarPocionesPorTipo() {
        // TODO
    }

    /**
     * Devuelve la potencia media de las pociones agrupadas por tipo.
     *
     * @return Lista de objetos donde [0] = nombre del tipo, [1] = potencia media.
     */
    public List<Object[]> obtenerPotenciaMediaPorTipo() {
        // TODO
    }

}
