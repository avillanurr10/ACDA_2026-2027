package org.pokemonpotionsmanager.connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Clase de utilidad para gestionar la configuración y el ciclo de vida
 * de la {@link SessionFactory} de Hibernate.
 *
 * <p>
 * Carga la configuración desde el archivo <code>hibernate.cfg.xml</code>
 * y proporciona métodos estáticos para obtener o cerrar la sesión global.
 * </p>
 *
 * @author Dani Durán
 * @version 1.1
 */
public class HibernateUtil {

    private static final Logger logger = LogManager.getLogger(HibernateUtil.class);

    /** Fábrica de sesiones de Hibernate (singleton). */
    private static final SessionFactory sessionFactory = buildSessionFactory();

    /**
     * Crea la {@link SessionFactory} utilizando la configuración predeterminada
     * definida en el archivo <code>hibernate.cfg.xml</code>.
     *
     * @return Instancia única de {@link SessionFactory}.
     */
    private static SessionFactory buildSessionFactory() {
        try {
            logger.info("Inicializando Hibernate SessionFactory...");
            return new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            logger.error("Error al crear la SessionFactory de Hibernate: {}", ex.getMessage(), ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    /**
     * Devuelve la instancia global de {@link SessionFactory}.
     *
     * @return {@link SessionFactory} inicializada.
     */
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    /**
     * Cierra la {@link SessionFactory} y libera los recursos asociados.
     * <p>Debe llamarse siempre al finalizar la aplicación.</p>
     */
    public static void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
            logger.info("SessionFactory cerrada correctamente.");
        }
    }
}
