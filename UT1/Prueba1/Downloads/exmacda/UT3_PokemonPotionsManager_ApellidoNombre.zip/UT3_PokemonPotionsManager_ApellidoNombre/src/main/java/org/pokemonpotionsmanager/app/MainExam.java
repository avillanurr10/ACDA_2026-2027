package org.pokemonpotionsmanager.app;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.pokemonpotionsmanager.connection.HibernateUtil;
import org.pokemonpotionsmanager.model.Pocion;
import org.pokemonpotionsmanager.model.Tipo;
import org.pokemonpotionsmanager.service.PocionService;
import org.pokemonpotionsmanager.service.TipoService;

import java.math.BigDecimal;
import java.util.List;

/**
 * Clase principal del examen UT3 – Hibernate.
 * <p>
 * Simula la gestión de pociones Pokémon mediante Hibernate ORM.
 * Crea registros de ejemplo, muestra listados y realiza consultas HQL
 * de filtrado y agregación.
 * </p>
 *
 * @author Dani Durán
 * @version 1.1
 */
public class MainExam {

    private static final Logger logger = LogManager.getLogger(MainExam.class);

    /**
     * Método principal de ejecución.
     *
     * @param args Argumentos de línea de comandos (no usados).
     */
    public static void main(String[] args) {
        logger.info("===== INICIO: Pokémon Potions Manager =====");

        TipoService tipoService = new TipoService();
        PocionService pocionService = new PocionService();

        try {
            // Crear tipos
            Tipo curacion = new Tipo("Curación", "Restaura puntos de vida");
            Tipo ataque = new Tipo("Ataque", "Aumenta daño");
            Tipo defensa = new Tipo("Defensa", "Reduce daño recibido");

            tipoService.insertar(curacion);
            tipoService.insertar(ataque);
            tipoService.insertar(defensa);

            // Crear pociones
            pocionService.insertar(new Pocion("Poción", 20.0, BigDecimal.valueOf(100.00), curacion));
            pocionService.insertar(new Pocion("Superpoción", 50, BigDecimal.valueOf(200), curacion));
            pocionService.insertar(new Pocion("Hiperpoción", 120, BigDecimal.valueOf(400), curacion));
            pocionService.insertar(new Pocion("X Ataque", 10, BigDecimal.valueOf(150), ataque));
            pocionService.insertar(new Pocion("X Defensa", 15, BigDecimal.valueOf(150), defensa));

            // Listar todas las pociones
            logger.info("===== LISTADO DE POCIONES =====");
            // TODO

            // Consulta 1: por tipo
            logger.info("===== CONSULTA: Pociones de tipo 'Curación' =====");
            // TODO

            // Consulta 2: por potencia mínima
            logger.info("===== CONSULTA: Pociones con potencia >= 50 =====");
            // TODO


            // Consulta 3: conteo de pociones por tipo
            logger.info("===== CONSULTA: Nº de Pociones por Tipo =====");
            // TODO


            // CONSULTA 4: Potencia media por tipo
            logger.info("===== CONSULTA: Potencia media por tipo =====");
            // TODO


        } catch (Exception e) {
            logger.error("Error en la ejecución del examen", e);
        } finally {
            HibernateUtil.closeSessionFactory();
            logger.info("===== FIN DEL PROGRAMA =====");
        }
    }
}
