package org.pokemonpotionsmanager.dao;

import java.util.List;

/**
 * Interfaz genérica que define las operaciones básicas CRUD
 * para cualquier entidad de la aplicación.
 *
 * <p>Se utiliza como base para los DAO específicos.</p>
 *
 * @param <T> Tipo de entidad gestionada.
 * @param <ID> Tipo de la clave primaria.
 *
 * @author Dani Durán
 * @version 1.0
 */
public interface IGenericDAO<T, ID> {

    /**
     * Inserta un nuevo registro en la base de datos.
     *
     * @param entidad Objeto a persistir.
     */
    void insertar(T entidad);

    /**
     * Actualiza un registro existente.
     *
     * @param entidad Objeto a actualizar.
     */
    void actualizar(T entidad);

    /**
     * Elimina un registro por su identificador.
     *
     * @param id Identificador del registro a eliminar.
     */
    void eliminar(ID id);

    /**
     * Recupera un registro por su identificador.
     *
     * @param id Identificador del registro.
     * @return Entidad encontrada, o null si no existe.
     */
    T buscarPorId(ID id);

    /**
     * Lista todos los registros de la tabla correspondiente.
     *
     * @return Lista con todas las entidades almacenadas.
     */
    List<T> listarTodos();
}
