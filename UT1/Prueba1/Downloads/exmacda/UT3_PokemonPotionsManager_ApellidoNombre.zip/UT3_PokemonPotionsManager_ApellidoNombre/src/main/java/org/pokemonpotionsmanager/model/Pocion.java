package org.pokemonpotionsmanager.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * Entidad que representa una poción Pokémon.
 * <p>
 * Cada poción pertenece a un {@link Tipo} determinado
 * y posee información sobre su potencia y precio.
 * </p>
 *
 * <h3>Atributos principales:</h3>
 * <ul>
 *     <li><b>nombre:</b> nombre de la poción (único y descriptivo).</li>
 *     <li><b>potencia:</b> valor numérico que representa su eficacia.</li>
 *     <li><b>precio:</b> coste en la moneda del juego (₽).</li>
 *     <li><b>tipo:</b> relación {@code ManyToOne} con la entidad {@link Tipo}.</li>
 * </ul>
 *
 * @author Dani Durán
 * @version 1.1
 */

public class Pocion {

    private int pocionID;
    private String nombre;
    private double potencia;
    private BigDecimal precio;
    private Tipo tipo;

    /** Constructor vacío requerido por JPA. */
    public Pocion() {}

    /**
     * Constructor completo para crear una poción.
     *
     * @param nombre  Nombre de la poción.
     * @param potencia  Potencia de la poción.
     * @param precio  Precio de la poción.
     * @param tipo  Tipo de poción al que pertenece.
     */
    public Pocion(String nombre, double potencia, BigDecimal precio, Tipo tipo) {
        this.nombre = nombre;
        this.potencia = potencia;
        this.precio = precio;
        this.tipo = tipo;
    }

    // === Getters y Setters ===

    public int getPocionID() {
        return pocionID;
    }

    public void setPocionID(int pocionID) {
        this.pocionID = pocionID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPotencia() {
        return potencia;
    }

    public void setPotencia(double potencia) {
        this.potencia = potencia;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    /**
     * Representación textual legible de la poción.
     *
     * @return Cadena descriptiva de la poción con su tipo, potencia y precio.
     */
    @Override
    public String toString() {
        return String.format("%s (%s) → Potencia %.1f | Precio %.2f₽",
                nombre,
                tipo != null ? tipo.getNombre() : "Sin tipo",
                potencia,
                precio);
    }
}
