package org.pokemonpotionsmanager.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Entidad que representa un tipo de poción Pokémon.
 * <p>
 * Cada tipo puede estar asociado a múltiples pociones
 * (relación {@code OneToMany} bidireccional).
 * </p>
 *
 * <h3>Atributos:</h3>
 * <ul>
 *     <li><b>nombre:</b> nombre corto del tipo (por ejemplo, "Curación").</li>
 *     <li><b>descripcion:</b> texto descriptivo de su efecto o propósito.</li>
 *     <li><b>pociones:</b> lista de pociones que pertenecen a este tipo.</li>
 * </ul>
 *
 * @see Pocion
 * @author Dani Durán
 * @version 1.1
 */

public class Tipo {

    private int tipoID;
    private String nombre;
    private String descripcion;

    /** Constructor vacío requerido por JPA. */
    public Tipo() {}

    /**
     * Constructor completo para inicializar un tipo.
     *
     * @param nombre      Nombre del tipo.
     * @param descripcion Descripción del tipo.
     */
    public Tipo(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // === Getters y Setters ===

    public int getTipoID() {
        return tipoID;
    }

    public void setTipoID(int tipoID) {
        this.tipoID = tipoID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Pocion> getPociones() {
        return pociones;
    }

    public void setPociones(List<Pocion> pociones) {
        this.pociones = pociones;
    }

    /**
     * Añade una poción a la lista y establece la relación inversa.
     *
     * @param pocion Pocion a asociar a este tipo.
     */
    public void addPocion(Pocion pocion) {
        pociones.add(pocion);
        pocion.setTipo(this);
    }

    /**
     * Elimina una poción de la lista y rompe la relación inversa.
     *
     * @param pocion Pocion a eliminar de este tipo.
     */
    public void removePocion(Pocion pocion) {
        pociones.remove(pocion);
        pocion.setTipo(null);
    }

    /**
     * Representación textual legible del tipo de poción.
     *
     * @return Cadena descriptiva del tipo.
     */
    @Override
    public String toString() {
        return String.format("%s (%s)", nombre, descripcion);
    }
}
