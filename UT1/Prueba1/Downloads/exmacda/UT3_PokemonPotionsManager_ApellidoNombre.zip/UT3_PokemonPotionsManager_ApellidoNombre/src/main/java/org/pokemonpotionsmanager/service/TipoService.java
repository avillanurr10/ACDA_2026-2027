package org.pokemonpotionsmanager.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.pokemonpotionsmanager.dao.TipoDAO;
import org.pokemonpotionsmanager.model.Tipo;

import java.util.List;

/**
 * Capa de servicio que gestiona la lógica de negocio
 * relacionada con los tipos de pociones Pokémon.
 * <p>
 * Ofrece operaciones de inserción, listado y una consulta
 * de agregación que muestra el número de pociones por tipo.
 * </p>
 *
 * @author Dani Durán
 * @version 1.1
 */
public class TipoService {

    private static final Logger logger = LogManager.getLogger(TipoService.class);
    private final TipoDAO tipoDAO = new TipoDAO();

    /**
     * Inserta un nuevo tipo en la base de datos y registra la operación en el log.
     * <p>
     * Este método se encarga también de mostrar por consola (vía {@code logger.info})
     * un mensaje confirmando que la inserción se ha realizado correctamente.
     * </p>
     *
     * @param tipo Objeto {@link Tipo} a insertar.
     */
    public void insertar(Tipo tipo) {
        // TODO
    }

    /**
     * Recupera y lista todos los tipos registrados.
     *
     * @return Lista de objetos {@link Tipo}.
     */
    public List<Tipo> listar() {
        // TODO
    }

    /**
     * Ejecuta una consulta HQL de agregación que cuenta el número de pociones por tipo.
     * <p>
     * Esta consulta no devuelve entidades completas, sino resultados agregados
     * representados como una lista de arreglos de objetos ({@code Object[]}):
     * <ul>
     *   <li>Posición [0]: nombre del tipo</li>
     *   <li>Posición [1]: número total de pociones asociadas a ese tipo</li>
     * </ul>
     * Cada fila del resultado se muestra por log en el siguiente formato:
     * <br>{@code Tipo 'Curación' tiene 2 pocione(s) registradas.}
     * </p>
     * <p>
     * Esta operación se realiza en el service (no en el main) porque el resultado
     * no son entidades {@link org.pokemonpotionsmanager.model.Pocion}, sino datos
     * agregados que requieren formateo previo.
     * </p>
     */
    public void mostrarConteoPociones() {
        // TODO
    }

    /**
     * Ejecuta una consulta HQL de agregación que calcula la potencia media de las
     * pociones agrupadas por tipo.
     * <p>
     * Al igual que en el conteo, esta consulta devuelve una lista de arreglos de objetos ({@code Object[]}),
     * donde:
     * <ul>
     *   <li>Posición [0]: nombre del tipo</li>
     *   <li>Posición [1]: potencia media (valor {@code Double})</li>
     * </ul>
     * <p>
     * El método se encarga de formatear y mostrar los resultados en consola mediante Log4j2,
     * siguiendo el formato:
     * <br>{@code Tipo 'Curación' → Potencia media: 85.0}
     * </p>
     * <p>
     * Se realiza desde el service porque los resultados no son instancias de {@link org.pokemonpotionsmanager.model.Pocion},
     * sino datos agregados a partir de la base de datos.
     * </p>
     */

    public void mostrarPotenciaMediaPorTipo() {
        logger.info("===== CONSULTA: Potencia media por tipo =====");
        // TODO
    }

}
