package org.acda.ut5_pokedex.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

/**
 * Data Transfer Object (DTO) que se utiliza para enviar y recibir datos
 * de Pokémon a través de la API REST.
 */
public class PokemonDto {

    // TODO: Implementar completamente esta clase (campos, validaciones y métodos)
    //       según lo indicado en el enunciado del examen.

}
