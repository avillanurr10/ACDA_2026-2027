package org.acda.ut5_pokedex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ut5PokedexApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ut5PokedexApplication.class, args);
    }

}
