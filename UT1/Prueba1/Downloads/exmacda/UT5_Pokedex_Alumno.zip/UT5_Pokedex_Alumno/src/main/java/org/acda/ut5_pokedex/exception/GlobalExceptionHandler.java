package org.acda.ut5_pokedex.exception;

import org.acda.ut5_pokedex.dto.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Manejador global de excepciones para la API REST.
 *
 * Convierte excepciones en respuestas JSON coherentes.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Maneja la excepción {@link PokemonNotFoundException} devolviendo 404.
     *
     * @param ex excepción lanzada.
     * @return respuesta con código 404 y mensaje de error.
     */
    @ExceptionHandler(PokemonNotFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handlePokemonNotFound(PokemonNotFoundException ex) {
        ApiResponse<Void> response = ApiResponse.error(ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }

    /**
     * Maneja errores de validación de los DTO.
     *
     * @param ex excepción de validación.
     * @return respuesta con código 400 (Bad Request).
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleValidationException(MethodArgumentNotValidException ex) {
        String message = ex.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .orElse("Datos de entrada no válidos");

        ApiResponse<Void> response = ApiResponse.error(message);
        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Maneja cualquier otra excepción no controlada.
     *
     * @param ex excepción producida.
     * @return respuesta con código 500 (Internal Server Error).
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleGenericException(Exception ex) {
        ApiResponse<Void> response = ApiResponse.error("Error interno del servidor");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}
