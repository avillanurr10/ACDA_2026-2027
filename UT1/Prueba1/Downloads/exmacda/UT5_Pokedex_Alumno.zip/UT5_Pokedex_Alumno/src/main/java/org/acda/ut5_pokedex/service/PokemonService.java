package org.acda.ut5_pokedex.service;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.acda.ut5_pokedex.dto.PokemonDto;
import org.acda.ut5_pokedex.exception.PokemonNotFoundException;
import org.acda.ut5_pokedex.model.Pokemon;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

/**
 * Servicio de negocio para gestionar Pokémon usando Firestore.
 *
 * Esta clase encapsula todo el acceso a la base de datos.
 */
@Service
public class PokemonService {

    private final Firestore firestore;

    @Value("${firebase.collection.pokemons}")
    private String collectionName;

    /**
     * Crea una nueva instancia del servicio inyectando Firestore.
     *
     * @param firestore instancia de {@link Firestore}.
     */
    public PokemonService(Firestore firestore) {
        this.firestore = firestore;
    }

    /**
     * Crea un nuevo Pokémon en Firestore.
     *
     * @param dto datos del Pokémon a crear.
     * @return DTO del Pokémon creado (incluyendo el id asignado).
     */
    public PokemonDto crear(PokemonDto dto) {
        // TODO: Implementar creación en Firestore según lo indicado en el enunciado:
        //  - Convertir el DTO a entidad
        //  - Generar id si no viene
        //  - Guardar en la colección correspondiente
        //  - Devolver el DTO del Pokémon creado con su id

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }


    /**
     * Lista los Pokémon aplicando filtros opcionales.
     *
     * @param tipo          tipo principal (opcional).
     * @param region        región (opcional).
     * @param legendario    indica si es legendario (opcional).
     * @param generacionMin generación mínima (opcional).
     * @param ataqueMin     ataque mínimo (opcional).
     * @return lista de Pokémon que cumplen los filtros.
     */
    public List<PokemonDto> listar(Optional<String> tipo,
                                   Optional<String> region,
                                   Optional<Boolean> legendario,
                                   Optional<Integer> generacionMin,
                                   Optional<Integer> ataqueMin) {
        // TODO: Implementar listado con filtros:
        //  - Aplicar en Firestore: tipo, region, legendario
        //  - Aplicar en Java (memoria): generacionMin, ataqueMin

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }



    /**
     * Busca un Pokémon por su identificador.
     *
     * @param id identificador del documento en Firestore.
     * @return DTO del Pokémon encontrado.
     * @throws PokemonNotFoundException si no existe el Pokémon.
     */
    public PokemonDto buscarPorId(String id) {
        // TODO: Implementar búsqueda por id en Firestore:
        //  - Si el documento no existe, lanzar PokemonNotFoundException
        //  - Si existe, convertir a DTO y devolver

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Actualiza un Pokémon existente.
     *
     * @param id  identificador del Pokémon a actualizar.
     * @param dto datos nuevos a aplicar.
     * @return DTO del Pokémon actualizado.
     * @throws PokemonNotFoundException si no existe el Pokémon.
     */
    public PokemonDto actualizar(String id, PokemonDto dto) {
        // TODO: Implementar actualización:
        //  - Comprobar que el documento existe (si no, PokemonNotFoundException)
        //  - Actualizar en Firestore con los datos del DTO
        //  - Devolver DTO actualizado

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Elimina un Pokémon por su identificador.
     *
     * @param id identificador del Pokémon a eliminar.
     * @throws PokemonNotFoundException si no existe el Pokémon.
     */
    public void borrar(String id) {
        // TODO: Implementar borrado:
        //  - Comprobar que el documento existe (si no, PokemonNotFoundException)
        //  - Eliminar el documento de Firestore

        // De momento este método no hace nada. Así el proyecto compila.
        // IMPORTANTE: cuando completes la implementación, elimina este comentario
        //             y añade la lógica de borrado.
    }

    /**
     * Convierte un DTO en entidad de dominio {@link Pokemon}.
     *
     * @param dto DTO de entrada.
     * @return entidad de dominio.
     */
    private Pokemon mapToEntity(PokemonDto dto) {
        Pokemon pokemon = new Pokemon();
        pokemon.setId(dto.getId());
        pokemon.setNombre(dto.getNombre());
        pokemon.setTipoPrincipal(dto.getTipoPrincipal());
        pokemon.setTipoSecundario(dto.getTipoSecundario());
        pokemon.setRegion(dto.getRegion());
        pokemon.setGeneracion(dto.getGeneracion());
        pokemon.setLegendario(dto.getLegendario());
        pokemon.setAtaque(dto.getAtaque());
        pokemon.setDefensa(dto.getDefensa());
        pokemon.setVelocidad(dto.getVelocidad());
        return pokemon;
    }

    /**
     * Convierte una entidad de dominio {@link Pokemon} en un DTO.
     *
     * @param pokemon entidad de dominio.
     * @return DTO resultante.
     */
    private PokemonDto mapToDto(Pokemon pokemon) {
        PokemonDto dto = new PokemonDto();
        dto.setId(pokemon.getId());
        dto.setNombre(pokemon.getNombre());
        dto.setTipoPrincipal(pokemon.getTipoPrincipal());
        dto.setTipoSecundario(pokemon.getTipoSecundario());
        dto.setRegion(pokemon.getRegion());
        dto.setGeneracion(pokemon.getGeneracion());
        dto.setLegendario(pokemon.getLegendario());
        dto.setAtaque(pokemon.getAtaque());
        dto.setDefensa(pokemon.getDefensa());
        dto.setVelocidad(pokemon.getVelocidad());
        return dto;
    }
}
