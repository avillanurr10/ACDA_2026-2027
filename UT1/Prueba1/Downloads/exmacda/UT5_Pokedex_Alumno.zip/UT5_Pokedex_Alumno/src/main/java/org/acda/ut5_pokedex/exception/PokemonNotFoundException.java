package org.acda.ut5_pokedex.exception;

/**
 * Excepción que se lanza cuando no se encuentra un Pokémon
 * con el identificador indicado en la base de datos.
 */
public class PokemonNotFoundException extends RuntimeException {

    /**
     * Crea la excepción con un mensaje incluyendo el identificador.
     *
     * @param id identificador del Pokémon no encontrado.
     */
    public PokemonNotFoundException(String id) {
        super("No se ha encontrado el Pokémon con id: " + id);
    }
}
