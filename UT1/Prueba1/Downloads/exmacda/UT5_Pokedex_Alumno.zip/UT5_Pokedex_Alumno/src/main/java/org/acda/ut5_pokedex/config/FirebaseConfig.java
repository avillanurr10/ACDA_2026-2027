package org.acda.ut5_pokedex.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;

/**
 * Configuración de Firebase y Firestore para la aplicación.
 *
 * Esta clase inicializa Firebase usando un fichero de credenciales
 * (service account) ubicado en el classpath y expone un {@link Firestore}
 * como bean de Spring para ser inyectado en los servicios.
 */
@Configuration
public class FirebaseConfig {

    @Value("${firebase.credentials}")
    private String credentialsPath;

    @Value("${firebase.project-id}")
    private String projectId;

    /**
     * Crea e inicializa el bean de Firestore.
     *
     * @return instancia de {@link Firestore} inicializada.
     * @throws IOException si hay problemas leyendo el fichero de credenciales.
     */
    @Bean
    public Firestore firestore() throws IOException {
        // Cargamos el JSON de credenciales desde resources
        ClassPathResource resource = new ClassPathResource(credentialsPath);

        try (InputStream serviceAccount = resource.getInputStream()) {
            GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(credentials)
                    .setProjectId(projectId)
                    .build();

            // Evitar inicializar más de una vez
            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }

            return FirestoreClient.getFirestore();
        }
    }
}
