package org.acda.ut5_pokedex.dto;

/**
 * Objeto de respuesta genérico para la API REST.
 *
 * @param <T> tipo de dato que se envía en el campo {@code data}.
 */
public class ApiResponse<T> {

    /**
     * Indica si la operación se ha realizado correctamente.
     */
    private boolean ok;

    /**
     * Mensaje adicional informativo sobre la operación.
     */
    private String message;

    /**
     * Datos devueltos por la operación (pueden ser null).
     */
    private T data;

    /**
     * Constructor vacío para frameworks.
     */
    public ApiResponse() {
    }

    /**
     * Crea una respuesta con todos los campos.
     *
     * @param ok      indica si la operación fue correcta.
     * @param message mensaje informativo.
     * @param data    datos devueltos por la operación.
     */
    public ApiResponse(boolean ok, String message, T data) {
        this.ok = ok;
        this.message = message;
        this.data = data;
    }

    /**
     * Crea una respuesta correcta sin datos.
     *
     * @param message mensaje informativo.
     * @param <T>     tipo del campo data.
     * @return respuesta con {@code ok=true} y {@code data=null}.
     */
    public static <T> ApiResponse<T> success(String message) {
        return new ApiResponse<>(true, message, null);
    }

    /**
     * Crea una respuesta correcta con datos.
     *
     * @param message mensaje informativo.
     * @param data    datos devueltos.
     * @param <T>     tipo del campo data.
     * @return respuesta con {@code ok=true}.
     */
    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(true, message, data);
    }

    /**
     * Crea una respuesta de error.
     *
     * @param message mensaje de error.
     * @param <T>     tipo del campo data.
     * @return respuesta con {@code ok=false}.
     */
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null);
    }

    // Getters y setters

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
