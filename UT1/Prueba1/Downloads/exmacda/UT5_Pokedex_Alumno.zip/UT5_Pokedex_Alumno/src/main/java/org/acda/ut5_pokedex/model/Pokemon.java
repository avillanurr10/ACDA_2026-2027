package org.acda.ut5_pokedex.model;

/**
 * Modelo de dominio que representa un Pokémon dentro de la aplicación.
 *
 * Esta clase se guarda como documento en la colección de Firestore.
 */
public class Pokemon {

    /**
     * Identificador del documento en Firestore.
     */
    private String id;

    /**
     * Nombre del Pokémon (por ejemplo, "Pikachu").
     */
    private String nombre;

    /**
     * Tipo principal del Pokémon (por ejemplo, "Eléctrico").
     */
    private String tipoPrincipal;

    /**
     * Tipo secundario del Pokémon (puede ser null si no tiene).
     */
    private String tipoSecundario;

    /**
     * Región a la que pertenece el Pokémon (Kanto, Johto, etc.).
     */
    private String region;

    /**
     * Número de generación (1, 2, 3, ...).
     */
    private Integer generacion;

    /**
     * Indica si el Pokémon es legendario.
     */
    private Boolean legendario;

    /**
     * Valor de ataque del Pokémon.
     */
    private Integer ataque;

    /**
     * Valor de defensa del Pokémon.
     */
    private Integer defensa;

    /**
     * Valor de velocidad del Pokémon.
     */
    private Integer velocidad;

    /**
     * Constructor vacío necesario para Firestore y frameworks.
     */
    public Pokemon() {
    }

    // Getters y setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoPrincipal() {
        return tipoPrincipal;
    }

    public void setTipoPrincipal(String tipoPrincipal) {
        this.tipoPrincipal = tipoPrincipal;
    }

    public String getTipoSecundario() {
        return tipoSecundario;
    }

    public void setTipoSecundario(String tipoSecundario) {
        this.tipoSecundario = tipoSecundario;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Integer getGeneracion() {
        return generacion;
    }

    public void setGeneracion(Integer generacion) {
        this.generacion = generacion;
    }

    public Boolean getLegendario() {
        return legendario;
    }

    public void setLegendario(Boolean legendario) {
        this.legendario = legendario;
    }

    public Integer getAtaque() {
        return ataque;
    }

    public void setAtaque(Integer ataque) {
        this.ataque = ataque;
    }

    public Integer getDefensa() {
        return defensa;
    }

    public void setDefensa(Integer defensa) {
        this.defensa = defensa;
    }

    public Integer getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(Integer velocidad) {
        this.velocidad = velocidad;
    }
}
