package org.acda.ut5_pokedex.controller;

import org.acda.ut5_pokedex.dto.ApiResponse;
import org.acda.ut5_pokedex.dto.PokemonDto;
import org.acda.ut5_pokedex.service.PokemonService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * Controlador REST para gestionar la Pokedex.
 *
 * Expone endpoints para crear, listar, consultar, actualizar y borrar Pokémon.
 */
@RestController
@RequestMapping("/api/pokemons")
@Validated
public class PokemonController {

    private final PokemonService pokemonService;

    /**
     * Crea el controlador inyectando el servicio de Pokémon.
     *
     * @param pokemonService servicio de negocio.
     */
    public PokemonController(PokemonService pokemonService) {
        this.pokemonService = pokemonService;
    }

    /**
     * Crea un nuevo Pokémon.
     *
     * @param dto datos del Pokémon a crear.
     * @return respuesta con el Pokémon creado.
     */
    @PostMapping
    public ResponseEntity<ApiResponse<PokemonDto>> crear(@Valid @RequestBody PokemonDto dto) {
        // TODO: Implementar este endpoint

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Lista los Pokémon aplicando filtros opcionales.
     *
     * @param tipo          tipo principal (opcional).
     * @param region        región (opcional).
     * @param legendario    legendario (opcional).
     * @param generacionMin generación mínima (opcional).
     * @param ataqueMin     ataque mínimo (opcional).
     * @return lista de Pokémon que cumplen los filtros.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<PokemonDto>>> listar(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) Boolean legendario,
            @RequestParam(required = false) Integer generacionMin,
            @RequestParam(required = false) Integer ataqueMin) {

        // TODO: Implementar este endpoint

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Obtiene un Pokémon por su identificador.
     *
     * @param id identificador del Pokémon.
     * @return Pokémon encontrado.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PokemonDto>> buscarPorId(@PathVariable String id) {
        // TODO: Implementar este endpoint

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Actualiza un Pokémon existente.
     *
     * @param id  identificador del Pokémon a actualizar.
     * @param dto datos nuevos.
     * @return Pokémon actualizado.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<PokemonDto>> actualizar(
            @PathVariable String id,
            @Valid @RequestBody PokemonDto dto) {

        // TODO: Implementar este endpoint

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }

    /**
     * Elimina un Pokémon por su identificador.
     *
     * @param id identificador del Pokémon a eliminar.
     * @return respuesta sin datos indicando éxito.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> borrar(@PathVariable String id) {
        // TODO: Implementar este endpoint

        // Mientras no implementes este método, este return permite que el proyecto compile.
        // IMPORTANTE: cuando completes la implementación, elimina este return null.
        return null;
    }
}
