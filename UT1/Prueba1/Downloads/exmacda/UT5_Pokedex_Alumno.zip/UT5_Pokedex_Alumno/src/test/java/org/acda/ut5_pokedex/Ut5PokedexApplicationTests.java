package org.acda.ut5_pokedex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ut5PokedexApplicationTests {

    @Test
    void contextLoads() {
    }

}
