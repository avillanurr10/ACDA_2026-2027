package org.zeldamultiverse.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.zeldamultiverse.model.Arma;
import org.zeldamultiverse.model.Personaje;
import org.zeldamultiverse.service.ArmaService;
import org.zeldamultiverse.service.PersonajeService;

import java.util.Optional;

/**
 * Controlador MVC para la gestión de personajes.
 *
 * Rutas base: /personajes
 */
@Controller
@RequestMapping("/personajes")
public class PersonajeController {

    private final PersonajeService personajeService;
    private final ArmaService armaService;

    /**
     * Crea el controlador con los servicios necesarios.
     *
     * @param personajeService servicio de personajes
     * @param armaService      servicio de armas
     */
    public PersonajeController(PersonajeService personajeService, ArmaService armaService) {
        this.personajeService = personajeService;
        this.armaService = armaService;
    }

    /**
     * Listado de personajes (/personajes).
     */
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("personajes", personajeService.findAll());
        return "personajes/lista";
    }

    /**
     * Detalle de personaje (/personajes/{id}).
     */
    @GetMapping("/{id}")
    public String detalle(@RequestParam Long id, Model model) {
        Optional<Personaje> opt = personajeService.findById(id);
        if (opt.isEmpty()) {
            return "redirect:/personajes";
        }
        Personaje personaje = opt.get();
        model.addAttribute("personaje", personaje);
        return "personajes/detalle";
    }

    /**
     * Formulario para crear un arma para un personaje.
     */
    @GetMapping("/{id}/armas/nueva")
    public String formularioArma(@PathVariable Long id, Model model) {
        Optional<Personaje> opt = personajeService.findById(id);
        if (opt.isEmpty()) {
            return "redirect:/personajes";
        }
        model.addAttribute("personaje", opt.get());
        model.addAttribute("arma", new Arma());
        return "armas/formulario";
    }

    /**
     * Crea un arma asociada al personaje y redirige a su detalle.
     */
    @PostMapping("/{id}/armas")
    public String crearArma(@PathVariable Long id,
                            @RequestParam String nombre,
                            @RequestParam String tipo,
                            @RequestParam Integer danio) {

        Optional<Personaje> opt = personajeService.findById(id);
        if (opt.isEmpty()) {
            return "redirect:/personajes";
        }

        Personaje personaje = opt.get();
        Arma arma = new Arma();
        arma.setNombre(nombre);
        arma.setTipo(tipo);
        arma.setDanio(danio);
        arma.setPersonaje(personaje);

        armaService.save(arma);

        return "redirect:/personajes/" + id;
    }
}
