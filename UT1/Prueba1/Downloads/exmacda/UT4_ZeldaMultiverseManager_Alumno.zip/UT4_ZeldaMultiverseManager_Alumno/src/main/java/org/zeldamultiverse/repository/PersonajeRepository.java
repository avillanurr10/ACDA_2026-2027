package org.zeldamultiverse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.zeldamultiverse.model.Personaje;

import java.util.List;

/**
 * Repositorio JPA para {@link Personaje}.
 */
public interface PersonajeRepository extends JpaRepository<Personaje, Long> {
    List<Personaje> id(Long id);
}
