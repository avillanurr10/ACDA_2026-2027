package org.zeldamultiverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ut4ZeldaMultiverseManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(Ut4ZeldaMultiverseManagerApplication.class, args);
    }
}
