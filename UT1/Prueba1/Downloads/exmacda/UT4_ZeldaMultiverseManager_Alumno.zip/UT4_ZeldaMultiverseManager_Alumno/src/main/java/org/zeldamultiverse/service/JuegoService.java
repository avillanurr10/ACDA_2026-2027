package org.zeldamultiverse.service;

import org.springframework.stereotype.Service;
import org.zeldamultiverse.model.Juego;
import org.zeldamultiverse.repository.JuegoRepository;

import java.util.List;
import java.util.Optional;

/**
 * Servicio de juegos.
 */
@Service
public class JuegoService {

    private final JuegoRepository repo;

    /**
     * Crea el servicio inyectando el repositorio.
     *
     * @param repo repositorio JPA de juegos
     */
    public JuegoService(JuegoRepository repo) {
        this.repo = repo;
    }

    /**
     * Devuelve todos los juegos.
     */
    public List<Juego> findAll() {
        return repo.findAll();
    }

    /**
     * Busca un juego por id.
     *
     * @param id identificador del juego
     * @return juego si existe
     */
    public Optional<Juego> findById(Long id) {
        return repo.findById(id);
    }

    /**
     * Guarda un juego.
     */
    public Juego save(Juego juego) {
        return repo.save(juego);
    }

    /**
     * Borra un juego por id.
     */
    public void deleteById(Long id) {
        repo.deleteById(id);
    }
}
