package org.zeldamultiverse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.zeldamultiverse.model.Mazmorra;

/**
 * Repositorio JPA para {@link Mazmorra}.
 */
public interface MazmorraRepository extends JpaRepository<Mazmorra, Long> {
}
