package org.zeldamultiverse.model;

import jakarta.persistence.*;
import java.util.*;

/**
 * Entidad que representa un juego de la saga Zelda.
 */
@Entity
@Table(name = "juego")
public class Juego {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;

    private Integer anio;

    @OneToMany(mappedBy = "juego", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Mazmorra> mazmorras = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "juego_personaje",
            joinColumns = @JoinColumn(name = "juego_id"),
            inverseJoinColumns = @JoinColumn(name = "personaje_id")
    )
    private Set<Personaje> personajes = new HashSet<>();

    /**
     * Constructor por defecto requerido por JPA.
     */
    public Juego() {
    }

    // Getters y setters básicos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public List<Mazmorra> getMazmorras() {
        return mazmorras;
    }

    public void setMazmorras(List<Mazmorra> mazmorras) {
        this.mazmorras = mazmorras;
    }

    public Set<Personaje> getPersonajes() {
        return personajes;
    }

    public void setPersonajes(Set<Personaje> personajes) {
        this.personajes = personajes;
    }

    /**
     * Añade una mazmorra al juego.
     */
    public void addMazmorra(Mazmorra mazmorra) {
        mazmorras.add(mazmorra);
        mazmorra.setJuego(this);
    }

    /**
     * Añade un personaje al juego.
     */
    public void addPersonaje(Personaje personaje) {
        personajes.add(personaje);
        personaje.getJuegos().add(this);
    }
}
