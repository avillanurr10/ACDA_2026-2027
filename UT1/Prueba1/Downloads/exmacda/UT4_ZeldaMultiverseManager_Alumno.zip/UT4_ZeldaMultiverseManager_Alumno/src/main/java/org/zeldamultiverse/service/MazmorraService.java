package org.zeldamultiverse.service;

import org.springframework.stereotype.Service;
import org.zeldamultiverse.model.Mazmorra;
import org.zeldamultiverse.repository.MazmorraRepository;

import java.util.List;
import java.util.Optional;

/**
 * Servicio de mazmorras.
 */
@Service
public class MazmorraService {

    private final MazmorraRepository repo;

    /**
     * Crea el servicio inyectando el repositorio.
     *
     * @param repo repositorio de mazmorras
     */
    public MazmorraService(MazmorraRepository repo) {
        this.repo = repo;
    }

    /**
     * Devuelve todas las mazmorras.
     */
    public List<Mazmorra> findAll() {
        return repo.findAll();
    }

    /**
     * Busca una mazmorra por id.
     *
     * @param id identificador
     * @return mazmorra si existe
     */
    public Optional<Mazmorra> findById(Long id) {
        return repo.findById(id);
    }
}
