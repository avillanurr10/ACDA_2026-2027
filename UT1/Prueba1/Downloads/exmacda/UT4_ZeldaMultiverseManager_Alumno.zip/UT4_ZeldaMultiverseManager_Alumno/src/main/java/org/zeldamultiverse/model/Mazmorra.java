package org.zeldamultiverse.model;

import jakarta.persistence.*;

/**
 * Entidad que representa una mazmorra perteneciente a un juego.
 */
@Entity
@Table(name = "mazmorra")
public class Mazmorra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String region;

    @ManyToOne
    @JoinColumn(name = "juego_id")
    private Juego juego;

    /**
     * Constructor por defecto requerido por JPA.
     */
    public Mazmorra() {
    }

    // Getters y setters básicos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Juego getJuego() {
        return juego;
    }

    public void setJuego(Juego juego) {
        this.juego = juego;
    }
}
