package org.zeldamultiverse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.zeldamultiverse.model.Juego;

/**
 * Repositorio JPA para {@link Juego}.
 */
public interface JuegoRepository extends JpaRepository<Juego, Long> {
}
