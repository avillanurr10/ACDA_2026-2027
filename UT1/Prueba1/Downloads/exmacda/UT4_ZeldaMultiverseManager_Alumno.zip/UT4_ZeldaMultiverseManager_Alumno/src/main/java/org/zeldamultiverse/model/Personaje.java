package org.zeldamultiverse.model;

import jakarta.persistence.*;
import java.util.*;

/**
 * Entidad que representa un personaje de la saga Zelda.
 */
@Entity
@Table(name = "personaje")
public class Personaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String raza;

    private Integer corazonMax;

    /**
     * Lista de armas del personaje.
     */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Arma> armas = new ArrayList<>();

    @ManyToMany(mappedBy = "personajes")
    private Set<Juego> juegos = new HashSet<>();

    /**
     * Constructor por defecto requerido por JPA.
     */
    public Personaje() {
    }

    // Getters y setters básicos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public Integer getCorazonMax() {
        return corazonMax;
    }

    public void setCorazonMax(Integer corazonMax) {
        this.corazonMax = corazonMax;
    }

    public List<Arma> getArmas() {
        return armas;
    }

    public void setArmas(List<Arma> armas) {
        this.armas = armas;
    }

    public Set<Juego> getJuegos() {
        return juegos;
    }

    public void setJuegos(Set<Juego> juegos) {
        this.juegos = juegos;
    }

    /**
     * Añade un arma al personaje.
     */
    public void addArma(Arma arma) {
        armas.add(arma);
        arma.setPersonaje(this);
    }
}
