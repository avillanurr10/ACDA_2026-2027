package org.zeldamultiverse.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.zeldamultiverse.model.Juego;
import org.zeldamultiverse.service.JuegoService;

import java.util.Optional;

/**
 * Controlador MVC para la gestión de juegos.
 *
 * Rutas base: /juegos
 */
@Controller
@RequestMapping("/juegos")
public class JuegoController {

    private final JuegoService juegoService;

    /**
     * Crea el controlador con el servicio de juegos.
     *
     * @param juegoService servicio de juegos
     */
    public JuegoController(JuegoService juegoService) {
        this.juegoService = juegoService;
    }

    /**
     * Detalle de un juego (/juegos/{id}).
     */
    @GetMapping("/{id}")
    public String detalle(@PathVariable Long id, Model model) {
        Optional<Juego> opt = juegoService.findById(id);
        if (opt.isEmpty()) {
            return "redirect:/juegos";
        }
        model.addAttribute("juego", opt.get());
        return "juegos/detalle";
    }

    /**
     * Muestra el formulario para crear un juego nuevo.
     */
    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("juego", new Juego());
        return "juegos/formulario";
    }

    /**
     * Muestra el formulario para editar un juego existente.
     */
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Optional<Juego> opt = juegoService.findById(id);
        if (opt.isEmpty()) {
            return "redirect:/juegos";
        }
        model.addAttribute("juego", opt.get());
        return "juegos/formulario";
    }

    /**
     * Guarda un juego (crear o actualizar).
     */
    @PostMapping
    public String guardar(@ModelAttribute("juego") Juego juegoForm) {
        if (juegoForm.getId() != null) {
            Optional<Juego> opt = juegoService.findById(juegoForm.getId());
            if (opt.isEmpty()) {
                return "redirect:/juegos";
            }
            Juego juegoBD = opt.get();
            juegoBD.setTitulo(juegoForm.getTitulo());
            juegoBD.setAnio(juegoForm.getAnio());
            juegoService.save(juegoBD);
        } else {
            juegoService.save(juegoForm);
        }
        return "redirect:/juegos";
    }

    /**
     * Borra un juego por id.
     */
    @GetMapping("/borrar/{id}")
    public String borrar(@PathVariable Long id) {
        juegoService.deleteById(id);
        return "redirect:/juegos";
    }
}
