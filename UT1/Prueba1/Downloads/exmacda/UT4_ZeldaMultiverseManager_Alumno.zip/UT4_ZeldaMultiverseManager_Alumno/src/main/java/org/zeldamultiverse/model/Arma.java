package org.zeldamultiverse.model;

import jakarta.persistence.*;

/**
 * Entidad que representa un arma asociada a un personaje.
 */
@Entity
@Table(name = "arma")
public class Arma {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private String tipo;

    private Integer danio;

    /**
     * Relación N:1 con personaje.
     */
    @ManyToOne
    @JoinColumn(name = "personajeID") // ← nombre de columna “raro” a propósito
    private Personaje personaje;

    /**
     * Constructor por defecto requerido por JPA.
     */
    public Arma() {
    }

    // Getters y setters básicos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getDanio() {
        return danio;
    }

    public void setDanio(Integer danio) {
        this.danio = danio;
    }

    public Personaje getPersonaje() {
        return personaje;
    }

    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }
}
