package org.zeldamultiverse.service;

import org.springframework.stereotype.Service;
import org.zeldamultiverse.model.Personaje;
import org.zeldamultiverse.repository.PersonajeRepository;

import java.util.List;
import java.util.Optional;

/**
 * Servicio de personajes.
 */
@Service
public class PersonajeService {

    private final PersonajeRepository repo;

    /**
     * Crea el servicio inyectando el repositorio.
     *
     * @param repo repositorio de personajes
     */
    public PersonajeService(PersonajeRepository repo) {
        this.repo = repo;
    }

    /**
     * Devuelve todos los personajes.
     */
    public List<Personaje> findAll() {
        return repo.findAll();
    }

    /**
     * Busca un personaje por id.
     *
     * @param id identificador
     * @return personaje si existe
     */
    public Optional<Personaje> findById(Long id) {
        return repo.findById(id);
    }

    /**
     * Guarda un personaje.
     */
    public Personaje save(Personaje personaje) {
        return repo.save(personaje);
    }
}
