package org.zeldamultiverse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.zeldamultiverse.model.Arma;

/**
 * Repositorio JPA para {@link Arma}.
 */
public interface ArmaRepository extends JpaRepository<Arma, Long> {
}
