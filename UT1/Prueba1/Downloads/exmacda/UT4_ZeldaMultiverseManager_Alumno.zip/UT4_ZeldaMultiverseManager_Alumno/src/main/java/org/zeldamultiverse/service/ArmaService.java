package org.zeldamultiverse.service;

import org.springframework.stereotype.Service;
import org.zeldamultiverse.model.Arma;
import org.zeldamultiverse.repository.ArmaRepository;

/**
 * Servicio de negocio para armas.
 */
@Service
public class ArmaService {

    private final ArmaRepository repo;

    /**
     * Crea el servicio recibiendo el repositorio.
     *
     * @param repo repositorio de armas
     */
    public ArmaService(ArmaRepository repo) {
    }

    /**
     * Guarda un arma en base de datos.
     *
     * @param arma entidad a persistir
     * @return arma persistida
     */
    public Arma save(Arma arma) {
        return repo.save(arma);
    }
}
