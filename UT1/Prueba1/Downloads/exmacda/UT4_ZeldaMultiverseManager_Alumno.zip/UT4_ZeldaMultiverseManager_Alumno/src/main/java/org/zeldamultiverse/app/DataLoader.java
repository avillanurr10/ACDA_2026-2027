package org.zeldamultiverse.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.zeldamultiverse.model.Arma;
import org.zeldamultiverse.model.Juego;
import org.zeldamultiverse.model.Mazmorra;
import org.zeldamultiverse.model.Personaje;
import org.zeldamultiverse.repository.ArmaRepository;
import org.zeldamultiverse.repository.JuegoRepository;
import org.zeldamultiverse.repository.MazmorraRepository;
import org.zeldamultiverse.repository.PersonajeRepository;

import java.util.List;

/**
 * Cargador de datos opcional para desarrollo/pruebas.
 *
 * Activación:
 * - application.properties -> seed.enabled=true
 *
 * Seguridad:
 * - Si ya hay datos (por ejemplo personajes), NO vuelve a insertar para evitar duplicados.
 *
 * Nota:
 * - Esta clase NO forma parte del examen; el alumnado no necesita modificarla.
 */
@Component
public class DataLoader implements CommandLineRunner {

    @Value("${seed.enabled:false}")
    private boolean seedEnabled;

    private final PersonajeRepository personajeRepo;
    private final JuegoRepository juegoRepo;
    private final ArmaRepository armaRepo;
    private final MazmorraRepository mazmorraRepo;

    public DataLoader(PersonajeRepository personajeRepo,
                      JuegoRepository juegoRepo,
                      ArmaRepository armaRepo,
                      MazmorraRepository mazmorraRepo) {
        this.personajeRepo = personajeRepo;
        this.juegoRepo = juegoRepo;
        this.armaRepo = armaRepo;
        this.mazmorraRepo = mazmorraRepo;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (!seedEnabled) return;

        // Evita duplicados: si ya existe contenido, no insertamos
        if (personajeRepo.count() > 0) return;

        // =========================
        // 1) Personajes
        // =========================
        Personaje link = personajeRepo.save(crearPersonaje("Link", "Hyliano", 20));
        Personaje zelda = personajeRepo.save(crearPersonaje("Zelda", "Hyliana", 12));
        Personaje ganondorf = personajeRepo.save(crearPersonaje("Ganondorf", "Gerudo", 30));
        Personaje impa = personajeRepo.save(crearPersonaje("Impa", "Sheikah", 16));
        Personaje sheik = personajeRepo.save(crearPersonaje("Sheik", "Sheikah", 18));
        Personaje midna = personajeRepo.save(crearPersonaje("Midna", "Crepúsculo", 14));
        Personaje skullKid = personajeRepo.save(crearPersonaje("Skull Kid", "Bosque", 10));
        Personaje navi = personajeRepo.save(crearPersonaje("Navi", "Hada", 3));
        Personaje tatl = personajeRepo.save(crearPersonaje("Tatl", "Hada", 3));
        Personaje darunia = personajeRepo.save(crearPersonaje("Darunia", "Goron", 22));
        Personaje ruto = personajeRepo.save(crearPersonaje("Ruto", "Zora", 16));
        Personaje saria = personajeRepo.save(crearPersonaje("Saria", "Kokiri", 12));
        Personaje fi = personajeRepo.save(crearPersonaje("Fi", "Espíritu", 8));
        Personaje vaati = personajeRepo.save(crearPersonaje("Vaati", "Hechicero", 18));
        Personaje tingle = personajeRepo.save(crearPersonaje("Tingle", "Humano", 9));

        // =========================
        // 2) Juegos (y relación M:N con personajes)
        //    En tu modelo, el lado propietario del M:N es Juego (tiene @JoinTable).
        //    Así que añadimos personajes a juego.getPersonajes() y guardamos el juego.
        // =========================
        Juego oot = new Juego();
        oot.setTitulo("Ocarina of Time");
        oot.setAnio(1998);
        oot.getPersonajes().addAll(List.of(link, zelda, ganondorf, impa, sheik, navi, darunia, ruto, saria));
        oot = juegoRepo.save(oot);

        Juego mm = new Juego();
        mm.setTitulo("Majora's Mask");
        mm.setAnio(2000);
        mm.getPersonajes().addAll(List.of(link, skullKid, tatl, tingle));
        mm = juegoRepo.save(mm);

        Juego tp = new Juego();
        tp.setTitulo("Twilight Princess");
        tp.setAnio(2006);
        tp.getPersonajes().addAll(List.of(link, zelda, ganondorf, midna));
        tp = juegoRepo.save(tp);

        Juego ss = new Juego();
        ss.setTitulo("Skyward Sword");
        ss.setAnio(2011);
        ss.getPersonajes().addAll(List.of(link, zelda, fi, impa));
        ss = juegoRepo.save(ss);

        Juego mc = new Juego();
        mc.setTitulo("The Minish Cap");
        mc.setAnio(2004);
        mc.getPersonajes().addAll(List.of(link, zelda, vaati));
        mc = juegoRepo.save(mc);

        // =========================
        // 3) Mazmorras (N:1 con Juego)
        // =========================
        mazmorraRepo.save(crearMazmorra("Inside the Deku Tree", "Bosque", oot));
        mazmorraRepo.save(crearMazmorra("Dodongo's Cavern", "Montaña", oot));
        mazmorraRepo.save(crearMazmorra("Jabu-Jabu's Belly", "Lago", oot));
        mazmorraRepo.save(crearMazmorra("Forest Temple", "Bosque", oot));
        mazmorraRepo.save(crearMazmorra("Fire Temple", "Montaña", oot));
        mazmorraRepo.save(crearMazmorra("Water Temple", "Lago", oot));
        mazmorraRepo.save(crearMazmorra("Shadow Temple", "Kakariko", oot));
        mazmorraRepo.save(crearMazmorra("Spirit Temple", "Desierto", oot));

        mazmorraRepo.save(crearMazmorra("Woodfall Temple", "Pantano", mm));
        mazmorraRepo.save(crearMazmorra("Snowhead Temple", "Nieve", mm));
        mazmorraRepo.save(crearMazmorra("Great Bay Temple", "Costa", mm));
        mazmorraRepo.save(crearMazmorra("Stone Tower Temple", "Cañón", mm));

        mazmorraRepo.save(crearMazmorra("Forest Temple (TP)", "Faron", tp));
        mazmorraRepo.save(crearMazmorra("Goron Mines", "Eldin", tp));
        mazmorraRepo.save(crearMazmorra("Lakebed Temple", "Lanayru", tp));
        mazmorraRepo.save(crearMazmorra("Arbiter's Grounds", "Desierto", tp));
        mazmorraRepo.save(crearMazmorra("Snowpeak Ruins", "Nieve", tp));
        mazmorraRepo.save(crearMazmorra("Temple of Time", "Ruinas", tp));

        mazmorraRepo.save(crearMazmorra("Skyview Temple", "Cielo", ss));
        mazmorraRepo.save(crearMazmorra("Earth Temple", "Volcán", ss));
        mazmorraRepo.save(crearMazmorra("Lanayru Mining Facility", "Desierto", ss));
        mazmorraRepo.save(crearMazmorra("Sandship", "Desierto", ss));

        mazmorraRepo.save(crearMazmorra("Deepwood Shrine", "Bosque", mc));
        mazmorraRepo.save(crearMazmorra("Cave of Flames", "Montaña", mc));
        mazmorraRepo.save(crearMazmorra("Fortress of Winds", "Cielo", mc));

        // =========================
        // 4) Armas (N:1 con Personaje)
        // =========================
        armaRepo.save(crearArma("Master Sword", "Espada", 95, link));
        armaRepo.save(crearArma("Hylian Shield", "Escudo", 10, link));
        armaRepo.save(crearArma("Bow", "Arco", 35, link));
        armaRepo.save(crearArma("Hookshot", "Herramienta", 5, link));

        armaRepo.save(crearArma("Light Arrows", "Magia", 70, zelda));
        armaRepo.save(crearArma("Sheikah Harp", "Instrumento", 15, sheik));
        armaRepo.save(crearArma("Gerudo Greatsword", "Espadón", 80, ganondorf));

        armaRepo.save(crearArma("Goron Bracelet", "Accesorio", 20, darunia));
        armaRepo.save(crearArma("Zora Boomerang", "Arma", 25, ruto));

        armaRepo.save(crearArma("Fused Shadow", "Reliquia", 60, midna));
        armaRepo.save(crearArma("Majora's Mask", "Artefacto", 55, skullKid));

        armaRepo.save(crearArma("Gust Jar", "Herramienta", 18, link)); // Minish
        armaRepo.save(crearArma("Four Sword", "Espada", 75, link));    // guiño multijuego
        armaRepo.save(crearArma("Picori Blade", "Espada", 40, link));

        armaRepo.save(crearArma("Tingle Balloon", "Artilugio", 7, tingle));

        // Listo. Si seed.enabled se deja en true, no duplicará porque count() > 0 en siguientes arranques.
    }

    private Personaje crearPersonaje(String nombre, String raza, int corazonMax) {
        Personaje p = new Personaje();
        p.setNombre(nombre);
        p.setRaza(raza);
        p.setCorazonMax(corazonMax);
        return p;
    }

    private Mazmorra crearMazmorra(String nombre, String region, Juego juego) {
        Mazmorra m = new Mazmorra();
        m.setNombre(nombre);
        m.setRegion(region);
        m.setJuego(juego);
        return m;
    }

    private Arma crearArma(String nombre, String tipo, int danio, Personaje personaje) {
        Arma a = new Arma();
        a.setNombre(nombre);
        a.setTipo(tipo);
        a.setDanio(danio);
        a.setPersonaje(personaje);
        return a;
    }
}
