package org.zeldamultiverse.ut4_zeldamultiversemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ut4ZeldaMultiverseManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
