package es.mariana.acda.ut1.examen.models;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class Ruta {
    private List<Checkpoint> checkpoints = new ArrayList<>();

    // Constructor y getter
    public Ruta(JSONArray ruta) {
        // TODO START parsea la ruta de un JSONArray a una lista de checkpoints

        // TODO END
    }

    public List<Checkpoint> getCheckpoints() {
        return checkpoints;
    }
}

