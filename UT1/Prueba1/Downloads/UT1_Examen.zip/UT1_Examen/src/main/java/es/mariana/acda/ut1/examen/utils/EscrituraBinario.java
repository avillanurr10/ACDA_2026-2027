package es.mariana.acda.ut1.examen.utils;

import es.mariana.acda.ut1.examen.models.Persona;

import java.io.IOException;
import java.util.List;

public class EscrituraBinario {

    public static void escribirBinarios(List<Persona> personas) throws IOException {
        // TODO START crea un fichero binario para cada persona con el contenido adecuado "id.bin"

        // TODO END
    }
}
