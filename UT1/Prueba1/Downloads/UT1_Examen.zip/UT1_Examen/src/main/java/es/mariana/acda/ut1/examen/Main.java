package es.mariana.acda.ut1.examen;

import es.mariana.acda.ut1.examen.utils.EscrituraBinario;
import es.mariana.acda.ut1.examen.utils.LecturaJSON;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // TODO START define la ruta relativa al fichero datos.json contenido en el directorio src/main/resources
        String rutaJSON = "";
        // TODO END

        // TODO START maneja el error avisando de qué en la lectura mediante un Sistem.out
        //          y termina la ejecución del programa
        JSONObject jsonObject = LecturaJSON.lecturaJSON(rutaJSON);
        // TODO END

        // TODO START transforma el jsonObject a la lista de Personas

        // TODO END

        // TODO START maneja el error avisando de de qué en la escritura mediante un Sistem.out
        EscrituraBinario.escribirBinarios();
        // TODO END
    }
}
